﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DestroyBackground : MonoBehaviour {

    private float CameraXPos;
	
	
	void Update ()
    {
        CameraXPos = Camera.main.transform.position.x;

        if ( CameraXPos > transform.position.x + 20 ) // if camera passed the background length
        {
            Destroy ( gameObject );
        }
	}


}

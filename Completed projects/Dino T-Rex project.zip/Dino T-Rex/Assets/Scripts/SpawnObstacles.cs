﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawnObstacles : MonoBehaviour {

    public GameObject [] obstacles;  //create array
    private GameObject obj;          //this will be each object in array that will be spawned
    private float XPos = 0;          
    private int number = 0;          //number that will be randomly generated

    private float randomPosition = 0;

	
	void Start ()
    {
        InvokeRepeating ( "Spawn", 1.5f, 1.6f );           //Starting in one and a half seconds, method "Spawn" will be repeated every 1.6 seconds
	}


    private void Spawn()
    {
        if ( GameObject.Find ( "Dino" ).GetComponent<Dino> ().isDead == false )
        {
            number = Random.Range ( 0, 7 );               //generate random number; when using integers, max is exclusive (7 not included)
            randomPosition = Random.Range (16, 26);       //16 is the width of the background; we want to spawn obstacle where the player can't see it
            XPos = transform.position.x + randomPosition; //x position of the object is 16 or more than x position of the camera
            obj = obstacles [ number ] as GameObject;     //obj is random game object from the array

            Instantiate ( obj, new Vector2 ( XPos, obj.transform.position.y ), Quaternion.identity );

        }
    }


}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Columns : MonoBehaviour {

    private Rigidbody2D rb;

	
	void Start ()
    {
        rb = GetComponent<Rigidbody2D>();
        rb.velocity = new Vector2(-1, 0);		
	}
	
	
	void Update ()
    {
        if (GameControls.instance.endGame == true)
        {
            rb.velocity = Vector2.zero;
        }
		
	}


    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.GetComponent<Bird>()!=null)
        {
            GameControls.instance.BirdScored();
        }
    }


}
